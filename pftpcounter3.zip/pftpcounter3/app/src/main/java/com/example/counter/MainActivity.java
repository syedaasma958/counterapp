package com.example.counter;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
int a=0;
    TextView Text;
    Button btncount,btnreset;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Text=findViewById(R.id.Text);
        btncount=findViewById(R.id.btncount);
        btnreset=findViewById(R.id.btnreset);

btncount.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        a++;
        Text.setText("Your count is: "+a);

    }
});
        btnreset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                a=0;
                Text.setText("Your count is:"+a);

            }
        });


    }
}